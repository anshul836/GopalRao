function loadData(status, btn) {
    if(btn) {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
    }

    let tbody = document.getElementById("tableBody");
    tbody.innerHTML = "<tr><td colspan='5' align='center'>Fetching data...</td></tr>";

    // FIX: Wrap criteria in parentheses
    let criteria = (status !== "All") ? `(Status == "${status}")` : "";

    ZOHO.CREATOR.API.getAllRecords({
        appName: WIDGET_CONFIG.APP,
        reportName: WIDGET_CONFIG.REPORT,
        criteria: criteria
    }).then(res => {
        let html = "";
        // Check for code 3000 (success) and presence of data
        if(res.code === 3000 && res.data && res.data.length > 0) {
            res.data.forEach(r => {
                html += `<tr>
                    <td class="clickable-link" onclick="fetchAtoZ('${r.ID}')">${r.Matter_Name || '-'}</td>
                    <td>${r.Matter_Number || '-'}</td>
                    <td><span class="status-pill">${r.Status || '-'}</span></td>
                    <td>${r.Open_Date || '-'}</td>
                    <td>${r.Practice_Area || '-'}</td>
                </tr>`;
            });
        } else {
            html = "<tr><td colspan='5' align='center'>No records found.</td></tr>";
        }
        tbody.innerHTML = html;
    }).catch(err => {
        console.error("Error:", err);
        tbody.innerHTML = "<tr><td colspan='5' align='center' style='color:red;'>Error loading data.</td></tr>";
    });
}

function openForm() {
    const formLinkName = "Contacts";
    const envMatch = window.location.pathname.match(/\/environment\/([^/]+)\//);
    const env = envMatch ? envMatch[1] : "development";
    const creatorBaseUrl = "https://creatorapp.zoho.com";

    // FIX: Added backticks for Template Literal
    const formUrl = `${creatorBaseUrl}/${WIDGET_CONFIG.OWNER}/environment/${env}/${WIDGET_CONFIG.APP}/#Form:${formLinkName}`;

    const popupWindow = window.open(formUrl, "contacts_form_popup", "width=1200,height=900");

    if (popupWindow) {
        popupWindow.focus();
        return;
    }

    // Fallback if popup is blocked
    const navFn = ZOHO?.CREATOR?.UTIL?.navigateParentURL;
    if (typeof navFn === "function") {
        navFn({ url: formUrl, windowName: "_parent" });
    }
}