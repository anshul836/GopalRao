// Global Configuration Object
const WIDGET_CONFIG = {
    OWNER: "gopalrao090",
    APP: "legal-case-management",
    REPORT: "All_Matters",
    NOTES:"All_Notes",
    ENV: "development" // Change to 'production' when live if needed
};

