// Global Configuration Object
const WIDGET_CONFIG = {
    OWNER: "gopalrao090",
    APP: "legal-case-management",
    REPORT: "All_Matters",
    ENV: "development" // Change to 'production' when live if needed
};

var RECORD_BY_ID_CONFIG= {
    app_name: "legal-case-management",
  report_name: "All_Matters",
  id : "4907914000000029023"
}