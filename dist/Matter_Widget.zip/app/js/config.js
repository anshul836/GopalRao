// Global Configuration Object
const WIDGET_CONFIG = {
    OWNER: "gopalrao090",
    APP: "legal-case-management",
    REPORT: "All_Matters",
    ENV: "development" // Change to 'production' when live if needed
};